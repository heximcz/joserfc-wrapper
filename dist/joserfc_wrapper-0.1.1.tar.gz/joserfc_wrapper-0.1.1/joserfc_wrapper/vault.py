import os
import hvac
from hvac.exceptions import InvalidPath
from joserfc_wrapper import AbstractKeyStorage


class vault(AbstractKeyStorage):
    def __init__(
        self,
        url: str = os.environ["VAULT_URL"],
        token: str = os.environ["VAULT_TOKEN"],
        mount: str = os.environ["VAULT_MOUNT"],
    ) -> None:
        """
        :url - default: os.environ['VAULT_URL']
        :token - defult: os.environ['VAULT_TOKEN']
        :mount - default os.environ["VAULT_MOUNT"]
        """
        self.__client = hvac.Client(url=url, token=token)
        self.__mount = mount

        # path for save last keys ID - default "last-key-id"
        self.last_id_path = "last-key-id"

    def get_last_id(self) -> str:
        result = self.__client.secrets.kv.v1.read_secret(
            path=self.last_id_path,
            mount_point=self.__mount,
        )
        return result["lid"]

    def load_keys(self, key_id: str) -> dict:
        result = self.__client.secrets.kv.v1.read_secret(
            path=key_id,
            mount_point=self.__mount,
        )
        return result

    def save_keys(self, key_id: str, secret: dict) -> None:
        """
        Save keys to vault

        :key_id - unicate id for keys name
        :secret - dict of a keys
            keys:
                {
                    'public': str,
                    'private': str
                }
        """
        self.__client.secrets.kv.v1.create_or_update_secret(
            mount_point=self.__mount, path=key_id, secret=secret
        )
        self.__save_last_id(key_id)


    def __save_last_id(self, key_id: str) -> None:
        secret = {"lid": key_id}

        self.__client.secrets.kv.v1.create_or_update_secret(
            mount_point=self.__mount, path=self.last_id_path, secret=secret
        )
