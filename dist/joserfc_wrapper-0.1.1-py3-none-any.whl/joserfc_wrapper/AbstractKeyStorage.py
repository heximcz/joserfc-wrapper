from abc import ABC, abstractmethod


class AbstractKeyStorage(ABC):
    """
    Abstract for keys storage
    """

    @abstractmethod
    def load_keys(self, key_id: str, mount: str) -> dict:
        pass

    @abstractmethod
    def save_kays(self, key_id: str, secret: dict) -> None:
        """
        Save keys to vault

        :key_id - unicate id for keys name
        :secret - dict of a keys
            keys:
                {
                    'public': str,
                    'private': str
                }
        """
        pass

    @abstractmethod
    def get_last_id(self) -> str:
        pass
