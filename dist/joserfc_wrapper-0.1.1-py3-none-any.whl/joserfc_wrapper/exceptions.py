from typing import Optional

class WrapperErrors(Exception):
    #: short-string error code
    error: str = ""
    #: long-string to describe this error
    description: str = ""

    def __init__(self, description: Optional[str] = None):
        if description is not None:
            self.description = description

        message = "{}: {}".format(self.error, self.description)
        super(WrapperErrors, self).__init__(message)

class StorageObjectError(WrapperErrors):
    error = "Storage parameter is not a object."

class GenerateKeysError(WrapperErrors):
    error = "Error when generate a new keys."

class KeysSaveError(WrapperErrors):
    error = "Unable to save files. Check the path is correct."

class KeysLoadError(WrapperErrors):
    error = "Unable to load files. Check the path is correct."